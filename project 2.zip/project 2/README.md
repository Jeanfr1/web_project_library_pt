# Projeto 1: Biblioteca Triple Peaks

A página da Biblioteca Triple Peaks é o primeiro projeto no programa de desenvolvedor de software na TripleTen. Ela é criada usando HTML e CSS, com base em um roteiro.

## Características do projeto

- HTML5 semântico
- Flexbox
- Posicionamento
- Empilhamento vertical com z-index
